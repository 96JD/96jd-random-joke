# 96JD Random Joke

Chrome extension that adds an element of humor to your browsing experience by delivering a new joke when you click on the extension's icon.

## Getting started

1. Select Extensions from Chrome Settings.
2. Enable developer mode.
3. Click on Load Unpacked and select your folder.
4. Click on the installed extension.

## Deployment

[https://jacob-dolorzo-random-joke.vercel.app](https://jacob-dolorzo-random-joke.vercel.app)

## Chrome Web Store

[https://chrome.google.com/webstore/detail/96jd-random-joke/gfnnlnoibgakclkjgbjeohenanehdolg?hl=en-US](https://chrome.google.com/webstore/detail/96jd-random-joke/gfnnlnoibgakclkjgbjeohenanehdolg?hl=en-US)
